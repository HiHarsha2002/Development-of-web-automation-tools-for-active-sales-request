select * from Scraped;
